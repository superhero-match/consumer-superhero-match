create
    definer = root@localhost procedure insert_new_match(IN id varchar(255), IN superhero_id varchar(255),
                                                        IN matched_superhero_id varchar(255),
                                                        IN created_at varchar(255))
BEGIN

INSERT INTO `match` (
		`match.id`,
		`match.superhero_id`,
		`choice.matched_superhero_id`,
		`choice.created_at`,
		`choice.deleted_at`
	)
	VALUES (
		id,
		superhero_id,
		matched_superhero_id,
		created_at,
        NULL
    );

END;

