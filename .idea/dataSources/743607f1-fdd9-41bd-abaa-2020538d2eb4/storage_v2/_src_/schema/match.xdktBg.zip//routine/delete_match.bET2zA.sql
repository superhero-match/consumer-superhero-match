create
    definer = root@localhost procedure delete_match(IN id varchar(255), IN deleted_at varchar(255))
BEGIN

UPDATE `match` 
SET `match.deleted_at` = deleted_at
WHERE `match.id` = id;

END;

